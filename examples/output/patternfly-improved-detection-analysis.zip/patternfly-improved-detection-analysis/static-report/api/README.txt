Paste your JSON files in this folder
